<template>
  <div class="com-page">
    <trend></trend>
  </div>
</template>

<script>
import Trend from '@/components/Trend'
export default {
  data () {
    return {}
  },
  methods: {},
  components: {
    trend: Trend
  }
}
</script>

<style lang="less" scoped>
</style>
